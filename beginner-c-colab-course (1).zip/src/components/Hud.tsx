import type { HudState } from "@/game/engine";
import type { Status } from "@/game/engine";

const fmt = (n: number) => n.toString().padStart(7, "0");

function Pip({ on }: { on: boolean }) {
  return (
    <span
      className={`h-2.5 w-2.5 rounded-[2px] border transition-colors duration-150 ${
        on ? "border-cyan bg-cyan shadow-[0_0_8px_#38e1ff]" : "border-edge bg-transparent"
      }`}
    />
  );
}

export function Hud({
  hud,
  status,
  best,
  onPause,
  onBomb,
  muted,
  onToggleMute,
}: {
  hud: HudState;
  status: Status;
  best: number;
  onPause: () => void;
  onBomb: () => void;
  muted: boolean;
  onToggleMute: () => void;
}) {
  const live = status === "playing";
  const ready = hud.charge >= 100;
  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* top bar */}
      <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-2 bg-gradient-to-b from-[#050a16]/95 via-[#050a16]/70 to-transparent px-2.5 pt-2 pb-6 sm:px-4 sm:pt-3">
        <div className="min-w-0">
          <div className="text-[9px] tracking-[0.32em] text-dim sm:text-[10px]">SCORE</div>
          <div className="-mt-0.5 text-xl leading-none font-extrabold tabular-nums text-ink drop-shadow-[0_0_10px_rgba(56,225,255,0.35)] sm:text-2xl">
            {fmt(hud.score)}
          </div>
          <div className="mt-1 text-[9px] tracking-[0.2em] text-faint sm:text-[10px]">BEST {fmt(best)}</div>
        </div>

        <div className="mt-0.5 min-w-0 flex-1 text-center">
          <div className="truncate text-[9px] tracking-[0.3em] text-amber sm:text-[11px]">{hud.waveSub}</div>
          <div className="truncate text-[11px] font-bold text-ink sm:text-sm">{hud.waveLabel}</div>
          {hud.boss !== null && (
            <div className="mx-auto mt-1 w-full max-w-[190px]">
              <div className="mb-0.5 flex justify-between text-[8px] tracking-[0.2em] text-rose">
                <span>SEGFAULT</span>
                <span>{Math.ceil(hud.boss * 100)}%</span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-black/60 ring-1 ring-rose/40">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-rose to-orange transition-[width] duration-150"
                  style={{ width: `${Math.max(0, hud.boss * 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col items-end gap-1.5">
          <div className="flex items-center gap-1">
            {[0, 1, 2, 3, 4].map((i) => (
              <span
                key={i}
                className={`h-3 w-2 rounded-[2px] border text-[8px] leading-none transition-all duration-150 ${
                  i < hud.lives
                    ? "border-lime bg-lime/80 shadow-[0_0_8px_rgba(124,227,139,0.7)]"
                    : "border-edge bg-black/40"
                }`}
              />
            ))}
          </div>
          <button
            onClick={onToggleMute}
            aria-label={muted ? "Unmute" : "Mute"}
            className="pointer-events-auto rounded-md border border-edge bg-panel/80 px-2 py-1 text-[9px] font-bold text-dim transition hover:border-cyan hover:text-cyan active:scale-95 sm:text-[10px]"
          >
            {muted ? "🔇" : "🔊"}
          </button>
          <button
            onClick={onPause}
            className="pointer-events-auto rounded-md border border-edge bg-panel/80 px-2 py-1 text-[9px] font-bold tracking-[0.18em] text-dim transition hover:border-cyan hover:text-cyan active:scale-95 sm:text-[10px]"
          >
            {live ? "❚❚ P" : "▶ P"}
          </button>
        </div>
      </div>

      {/* bottom-left status chips */}
      <div className="absolute bottom-2 left-2 flex flex-col gap-1.5 sm:bottom-3 sm:left-3">
        <div className="flex items-center gap-1.5 rounded-md border border-edge bg-black/55 px-2 py-1">
          <span className="text-[8px] tracking-[0.2em] text-faint">WEAPON</span>
          <span className="flex gap-1">
            {[1, 2, 3, 4].map((i) => (
              <Pip key={i} on={i <= hud.weapon} />
            ))}
          </span>
        </div>
        {hud.rapid > 0 && (
          <div className="cr-pop flex items-center gap-1.5 rounded-md border border-amber/60 bg-amber/10 px-2 py-1 text-[9px] font-bold tracking-[0.16em] text-amber">
            -O2 FAST {hud.rapid.toFixed(1)}s
          </div>
        )}
        {hud.shield && (
          <div className="cr-pop rounded-md border border-violet/60 bg-violet/10 px-2 py-1 text-[9px] font-bold tracking-[0.16em] text-violet">
            try {"{ catch }"} ARMED
          </div>
        )}
      </div>

      {/* bomb button */}
      <button
        onPointerDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onBomb();
        }}
        className={`pointer-events-auto absolute right-2 bottom-2 flex items-center gap-2 rounded-xl border px-3 py-2 text-left transition active:scale-95 sm:right-3 sm:bottom-3 ${
          ready
            ? "cr-pulse-ring border-cyan bg-cyan/20 text-cyan"
            : "border-edge bg-black/55 text-faint"
        }`}
      >
        <span className="text-[10px] font-extrabold tracking-[0.14em]">g++ -O2</span>
        <span className="relative block h-2 w-12 overflow-hidden rounded-full bg-black/70 ring-1 ring-inset ring-white/10">
          <span
            className="absolute inset-y-0 left-0 rounded-full bg-cyan transition-[width] duration-200"
            style={{ width: `${hud.charge}%` }}
          />
        </span>
        <span className="text-[9px] tabular-nums opacity-70">{ready ? "READY" : `${hud.charge}%`}</span>
      </button>
    </div>
  );
}
