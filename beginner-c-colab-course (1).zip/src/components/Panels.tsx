import type { HudState } from "@/game/engine";
import type { ScoreEntry } from "@/game/storage";
import { C } from "@/game/theme";
import { lessonForWave } from "@/game/lessons";

function Cell({
  tag,
  children,
  accent = "text-faint",
}: {
  tag: string;
  children: React.ReactNode;
  accent?: string;
}) {
  return (
    <div className="overflow-hidden rounded-lg border border-edge bg-black/40">
      <div className={`border-b border-edge px-2.5 py-1 text-[8px] tracking-[0.24em] ${accent}`}>{tag}</div>
      <div className="px-2.5 py-2 text-[10px] leading-relaxed">{children}</div>
    </div>
  );
}

export function NotebookPanel({ hud }: { hud: HudState }) {
  const lesson = lessonForWave(hud.wave);
  const file = `lesson${String(hud.wave).padStart(2, "0")}.cpp`;
  return (
    <aside className="hidden w-[268px] shrink-0 flex-col gap-2.5 xl:flex">
      <div>
        <div className="text-[9px] tracking-[0.34em] text-faint">COLAB NOTEBOOK</div>
        <div className="text-sm font-extrabold tracking-tight text-ink">beginner_cpp.ipynb</div>
      </div>

      <Cell tag="CELL 1 · SETUP">
        <span className="text-faint">!which g++ || (apt-get update -qq</span>
        <br />
        <span className="text-faint">&amp;&amp; apt-get install -y -qq g++)</span>
        <div className="mt-1.5 text-lime">✔ compiler ready</div>
      </Cell>

      <Cell tag={`CELL ${hud.wave + 1} · SOURCE`} accent="text-violet">
        <div className="text-violet">%%writefile {file}</div>
        <div className="mt-1 text-dim">
          <span className="text-violet">#include</span> <span className="text-ink">&lt;{lesson.title.toLowerCase().replace(/[^a-z]+/g, "_")}&gt;</span>
        </div>
        <div className="text-ink">int main() {"{"}</div>
        <div className="pl-3 text-cyan">std::cout &lt;&lt; "{lesson.title}";</div>
        <div className="text-ink">{"}"}</div>
      </Cell>

      <Cell tag="COMPILE &amp; RUN" accent="text-amber">
        <span className="break-all text-amber">
          !g++ -std=c++17 -Wall -Wextra {file} -o {file.replace(".cpp", "")} &amp;&amp; ./{file.replace(".cpp", "")}
        </span>
      </Cell>

      <Cell tag="OUTPUT" accent="text-lime">
        {hud.log.length ? (
          <div className="space-y-0.5">
            {hud.log.map((line, i) => (
              <div key={`${line}-${i}`} className={i === 0 ? "text-lime" : "text-faint"}>
                {line}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-faint">waiting for wave 1…</div>
        )}
      </Cell>

      <Cell tag="LESSON TIP" accent="text-cyan">
        <div className="text-ink">{lesson.tip}</div>
      </Cell>
    </aside>
  );
}

export function ScorePanel({ scores, hud }: { scores: ScoreEntry[]; hud: HudState }) {
  return (
    <aside className="hidden w-[252px] shrink-0 flex-col gap-2.5 xl:flex">
      <div>
        <div className="text-[9px] tracking-[0.34em] text-faint">RUN STATS</div>
        <div className="grid grid-cols-2 gap-2">
          {[
            { l: "BUGS", v: String(hud.kills), c: C.lime },
            { l: "WEAPON", v: `L${hud.weapon}`, c: C.cyan },
            { l: "CHARGE", v: `${hud.charge}%`, c: C.amber },
            { l: "WAVE", v: String(hud.wave), c: C.violet },
          ].map((s) => (
            <div key={s.l} className="rounded-lg border border-edge bg-black/40 px-2 py-1.5">
              <div className="text-[8px] tracking-[0.2em] text-faint">{s.l}</div>
              <div className="text-sm font-extrabold tabular-nums" style={{ color: s.c }}>
                {s.v}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="min-h-0">
        <div className="mb-1.5 text-[9px] tracking-[0.34em] text-faint">HIGH SCORES</div>
        <div className="overflow-hidden rounded-lg border border-edge">
          {scores.length === 0 ? (
            <div className="px-2.5 py-3 text-center text-[9px] tracking-[0.16em] text-faint">NO BUILDS LOGGED</div>
          ) : (
            scores.map((s, i) => (
              <div
                key={`${s.name}-${s.date}-${i}`}
                className={`flex items-center gap-2 px-2.5 py-1.5 text-[10px] ${i % 2 ? "bg-black/30" : ""}`}
              >
                <span className="w-4 text-faint">{i + 1}</span>
                <span className="flex-1 truncate font-bold tracking-[0.1em] text-ink">{s.name}</span>
                <span className="text-dim tabular-nums">W{s.wave}</span>
                <span className="w-14 text-right tabular-nums text-cyan">{s.score.toLocaleString()}</span>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="min-h-0">
        <div className="mb-1.5 text-[9px] tracking-[0.34em] text-faint">ENEMY DOSSIER</div>
        <div className="space-y-1.5">
          {[
            { c: C.lime, n: "syntax bug", d: "Drifts down, occasionally throws errors.", v: "100" },
            { c: C.blue, n: "nullptr", d: "Fast diver. Do not let it dereference you.", v: "160" },
            { c: C.violet, n: "memory leak", d: "Tanky blob that splits when freed.", v: "320" },
            { c: C.rose, n: "segfault", d: "Boss. Radial error bursts.", v: "2500+" },
          ].map((e) => (
            <div key={e.n} className="flex gap-2 rounded-lg border border-edge bg-black/40 px-2 py-1.5">
              <span
                className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full"
                style={{ background: e.c, boxShadow: `0 0 10px ${e.c}` }}
              />
              <div className="min-w-0">
                <div className="flex items-baseline gap-1.5">
                  <span className="text-[10px] font-bold" style={{ color: e.c }}>
                    {e.n}
                  </span>
                  <span className="text-[9px] text-faint">{e.v}</span>
                </div>
                <div className="text-[9px] leading-snug text-dim">{e.d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-auto rounded-lg border border-edge bg-black/40 px-2.5 py-2 text-[9px] leading-relaxed text-faint">
        Pickups: <span className="text-amber">-O2</span> rapid fire ·{" "}
        <span className="text-cyan">vec</span> weapon up · <span className="text-violet">try</span> shield ·{" "}
        <span className="text-lime">+1</span> retry token
      </div>
    </aside>
  );
}
