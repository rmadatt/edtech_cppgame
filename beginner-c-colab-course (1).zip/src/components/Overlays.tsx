import { useEffect, useMemo, useRef, useState } from "react";
import type { RunResult } from "@/game/engine";
import type { ScoreEntry } from "@/game/storage";
import { C } from "@/game/theme";

/* ------------------------------------------------------------------ shared */

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center overflow-hidden bg-[#040814]/88 px-3 py-4 backdrop-blur-[3px]">
      <div className="max-h-full w-full max-w-[440px] overflow-y-auto">{children}</div>
    </div>
  );
}

function TypeLine({ text, speed = 26 }: { text: string; speed?: number }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    setN(0);
    const id = setInterval(() => {
      setN((v) => {
        if (v >= text.length) {
          clearInterval(id);
          return v;
        }
        return v + 1;
      });
    }, speed);
    return () => clearInterval(id);
  }, [text, speed]);
  return (
    <span className="text-lime">
      {text.slice(0, n)}
      {n < text.length ? <span className="cr-caret">▌</span> : ""}
    </span>
  );
}

/* ------------------------------------------------------------- start screen */

const CMD = "!g++ -std=c++17 -Wall rush.cpp -o rush && ./rush";

export function StartScreen({ best, onStart }: { best: number; onStart: () => void }) {
  return (
    <Shell>
      <div className="cr-pop rounded-xl border border-edge bg-panel/90 p-4 shadow-[0_0_60px_rgba(56,225,255,0.12)] sm:p-5">
        <div className="text-[9px] tracking-[0.4em] text-faint">BEGINNER C++ · COLAB NOTEBOOK</div>
        <h1 className="mt-1 text-3xl leading-none font-extrabold tracking-tight text-ink sm:text-4xl">
          COMPILE
          <span className="text-cyan drop-shadow-[0_0_14px_rgba(56,225,255,0.6)]"> RUSH</span>
        </h1>
        <p className="mt-2 text-[11px] leading-relaxed text-dim sm:text-xs">
          <span className="text-violet">#include</span> <span className="text-ink">&lt;bugs&gt;</span> — the notebook is
          crawling with segfaults. Fly the compiler, zap the bugs, ship a clean build.
        </p>

        <div className="mt-3 overflow-hidden rounded-lg border border-edge bg-black/60">
          <div className="flex items-center gap-1.5 border-b border-edge px-2.5 py-1.5">
            <span className="h-2 w-2 rounded-full bg-rose/80" />
            <span className="h-2 w-2 rounded-full bg-amber/80" />
            <span className="h-2 w-2 rounded-full bg-lime/80" />
            <span className="ml-1 text-[9px] tracking-[0.2em] text-faint">rush.ipynb</span>
          </div>
          <div className="relative px-3 py-2.5 text-[10px] leading-relaxed sm:text-[11px]">
            <div className="absolute inset-x-0 top-0 h-6 bg-gradient-to-b from-cyan/10 to-transparent cr-scan" />
            <div className="whitespace-pre-wrap break-all">
              <span className="text-faint">[1] </span>
              <TypeLine text={CMD} />
            </div>
            <div className="mt-1.5 text-cyan/90">
              Hello, C++!<span className="cr-caret">▌</span>
            </div>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2 text-[10px] sm:text-[11px]">
          <div className="rounded-lg border border-edge bg-black/40 p-2.5">
            <div className="mb-1 text-[9px] tracking-[0.24em] text-amber">⌨ KEYBOARD</div>
            <ul className="space-y-0.5 text-dim">
              <li>
                <b className="text-ink">WASD / ←↑→↓</b> fly
              </li>
              <li>
                <b className="text-ink">SPACE</b> clean build
              </li>
              <li>
                <b className="text-ink">P / ESC</b> pause
              </li>
            </ul>
          </div>
          <div className="rounded-lg border border-edge bg-black/40 p-2.5">
            <div className="mb-1 text-[9px] tracking-[0.24em] text-cyan">👆 TOUCH</div>
            <ul className="space-y-0.5 text-dim">
              <li>
                <b className="text-ink">Drag</b> anywhere to fly
              </li>
              <li>Shooting is automatic</li>
              <li>
                <b className="text-ink">g++ -O2</b> button = bomb
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-4 gap-1.5 text-center text-[8px] leading-tight sm:text-[9px]">
          {[
            { c: C.lime, n: "bug", v: "100" },
            { c: C.blue, n: "null", v: "160" },
            { c: C.violet, n: "leak", v: "320" },
            { c: C.rose, n: "boss", v: "2.5k" },
          ].map((e) => (
            <div key={e.n} className="rounded-md border border-edge bg-black/40 px-1 py-1.5">
              <div className="mx-auto mb-1 h-2 w-2 rounded-full" style={{ background: e.c, boxShadow: `0 0 8px ${e.c}` }} />
              <div className="text-dim">{e.n}</div>
              <div className="font-bold" style={{ color: e.c }}>
                {e.v}
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onStart}
          className="mt-4 w-full rounded-lg border border-cyan/70 bg-gradient-to-b from-cyan/25 to-cyan/5 py-3 text-sm font-extrabold tracking-[0.22em] text-cyan shadow-[0_0_30px_rgba(56,225,255,0.25)] transition hover:from-cyan/40 hover:to-cyan/10 active:scale-[0.98]"
        >
          ▶ RUN ./compile_rush
        </button>
        <div className="mt-2 flex items-center justify-between text-[9px] tracking-[0.16em] text-faint">
          <span>
            PRESS <b className="text-dim">ENTER</b> · 12 WAVES
          </span>
          <span>
            BEST <b className="text-amber">{best.toLocaleString()}</b>
          </span>
        </div>
      </div>
    </Shell>
  );
}

/* ------------------------------------------------------------ pause screen */

export function PauseScreen({
  onResume,
  onRestart,
  onMenu,
}: {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <Shell>
      <div className="cr-pop rounded-xl border border-edge bg-panel/92 p-5 text-center">
        <div className="text-[9px] tracking-[0.4em] text-faint">BREAKPOINT HIT</div>
        <h2 className="mt-1 text-2xl font-extrabold tracking-[0.2em] text-cyan">PAUSED</h2>
        <p className="mt-2 text-[11px] text-dim">Process suspended. The bugs are waiting…</p>
        <div className="mt-4 space-y-2">
          <button
            onClick={onResume}
            className="w-full rounded-lg border border-cyan/70 bg-cyan/15 py-2.5 text-xs font-bold tracking-[0.2em] text-cyan transition hover:bg-cyan/25 active:scale-[0.98]"
          >
            ▶ RESUME
          </button>
          <button
            onClick={onRestart}
            className="w-full rounded-lg border border-edge bg-black/40 py-2.5 text-xs font-bold tracking-[0.2em] text-dim transition hover:border-amber hover:text-amber active:scale-[0.98]"
          >
            ⟳ RESTART
          </button>
          <button
            onClick={onMenu}
            className="w-full rounded-lg border border-edge bg-black/40 py-2.5 text-xs font-bold tracking-[0.2em] text-dim transition hover:border-rose hover:text-rose active:scale-[0.98]"
          >
            ⏻ QUIT TO MENU
          </button>
        </div>
      </div>
    </Shell>
  );
}

/* ---------------------------------------------------------- game over screen */

function ScoreTable({ scores, highlight }: { scores: ScoreEntry[]; highlight: number }) {
  if (!scores.length)
    return (
      <div className="rounded-lg border border-dashed border-edge px-3 py-4 text-center text-[10px] tracking-[0.16em] text-faint">
        NO BUILDS LOGGED YET
      </div>
    );
  return (
    <div className="overflow-hidden rounded-lg border border-edge">
      <div className="grid grid-cols-[24px_1fr_auto_auto] gap-2 border-b border-edge bg-black/50 px-2.5 py-1.5 text-[8px] tracking-[0.2em] text-faint">
        <span>#</span>
        <span>HACKER</span>
        <span className="text-right">WAVE</span>
        <span className="text-right">SCORE</span>
      </div>
      {scores.map((s, i) => {
        const hot = s.score === highlight;
        return (
          <div
            key={`${s.name}-${s.date}-${i}`}
            className={`grid grid-cols-[24px_1fr_auto_auto] items-center gap-2 px-2.5 py-1.5 text-[11px] ${
              hot ? "bg-cyan/15 text-cyan" : i % 2 ? "bg-black/20" : ""
            }`}
          >
            <span className={hot ? "font-bold" : "text-faint"}>{i + 1}</span>
            <span className="truncate font-bold tracking-[0.1em]">{s.name}</span>
            <span className="text-right text-dim tabular-nums">{s.wave}</span>
            <span className="text-right tabular-nums">{s.score.toLocaleString()}</span>
          </div>
        );
      })}
    </div>
  );
}

export function GameOverScreen({
  result,
  scores,
  isRecord,
  onSubmit,
  onRestart,
  onMenu,
}: {
  result: RunResult;
  scores: ScoreEntry[];
  isRecord: boolean;
  onSubmit: (name: string) => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  const [name, setName] = useState("YOU");
  const inputRef = useRef<HTMLInputElement>(null);
  const best = useMemo(() => scores.reduce((m, s) => Math.max(m, s.score), 0), [scores]);

  useEffect(() => {
    if (isRecord) inputRef.current?.focus();
  }, [isRecord]);

  return (
    <Shell>
      <div className="cr-pop rounded-xl border border-rose/40 bg-panel/92 p-4 shadow-[0_0_60px_rgba(255,90,122,0.15)] sm:p-5">
        <div className="text-[9px] tracking-[0.4em] text-faint">PROCESS EXITED · CODE 139</div>
        <h2 className="mt-1 text-2xl leading-tight font-extrabold tracking-tight text-rose sm:text-3xl">
          SEGMENTATION FAULT
        </h2>

        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          {[
            { l: "SCORE", v: result.score.toLocaleString(), c: "text-ink" },
            { l: "WAVE", v: String(result.wave), c: "text-amber" },
            { l: "BUGS", v: String(result.kills), c: "text-lime" },
          ].map((s) => (
            <div key={s.l} className="rounded-lg border border-edge bg-black/45 px-1 py-2">
              <div className="text-[8px] tracking-[0.2em] text-faint">{s.l}</div>
              <div className={`text-base font-extrabold tabular-nums sm:text-lg ${s.c}`}>{s.v}</div>
            </div>
          ))}
        </div>

        {isRecord ? (
          <form
            className="mt-3 rounded-lg border border-amber/50 bg-amber/10 p-3"
            onSubmit={(e) => {
              e.preventDefault();
              onSubmit((name.trim() || "YOU").slice(0, 6).toUpperCase());
            }}
          >
            <div className="text-[9px] tracking-[0.24em] text-amber">★ NEW HIGH SCORE — LOG YOUR HANDLE</div>
            <div className="mt-2 flex gap-2">
              <input
                ref={inputRef}
                value={name}
                maxLength={6}
                onChange={(e) => setName(e.target.value.toUpperCase().replace(/[^A-Z0-9_ ]/g, ""))}
                className="min-w-0 flex-1 rounded-md border border-edge bg-black/60 px-2.5 py-2 text-sm font-bold tracking-[0.2em] text-ink outline-none focus:border-amber"
              />
              <button
                type="submit"
                className="rounded-md border border-amber/70 bg-amber/20 px-3 py-2 text-[11px] font-bold tracking-[0.16em] text-amber transition hover:bg-amber/30 active:scale-95"
              >
                SAVE
              </button>
            </div>
          </form>
        ) : (
          <div className="mt-3 text-center text-[10px] tracking-[0.16em] text-faint">
            BEST <b className="text-amber">{best.toLocaleString()}</b>
          </div>
        )}

        <div className="mt-3">
          <div className="mb-1.5 text-[9px] tracking-[0.28em] text-faint">HIGH SCORES</div>
          <ScoreTable scores={scores} highlight={isRecord ? -1 : result.score} />
        </div>

        <button
          onClick={onRestart}
          className="mt-4 w-full rounded-lg border border-cyan/70 bg-gradient-to-b from-cyan/25 to-cyan/5 py-3 text-sm font-extrabold tracking-[0.2em] text-cyan transition hover:from-cyan/40 active:scale-[0.98]"
        >
          ⟳ RECOMPILE &amp; RETRY
        </button>
        <div className="mt-2 flex items-center justify-between text-[9px] tracking-[0.16em] text-faint">
          <span>
            PRESS <b className="text-dim">R</b> TO RESTART
          </span>
          <button onClick={onMenu} className="tracking-[0.16em] transition hover:text-dim">
            MENU
          </button>
        </div>
      </div>
    </Shell>
  );
}
