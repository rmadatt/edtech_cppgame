import { useCallback, useEffect, useRef, useState } from "react";
import { Game, H, W } from "@/game/engine";
import type { HudState, RunResult, Status } from "@/game/engine";
import { bestScore, isHighScore, loadScores, saveScore } from "@/game/storage";
import { sfx } from "@/game/audio";
import type { ScoreEntry } from "@/game/storage";
import { Hud } from "@/components/Hud";
import { GameOverScreen, PauseScreen, StartScreen } from "@/components/Overlays";
import { NotebookPanel, ScorePanel } from "@/components/Panels";

const EMPTY_HUD: HudState = {
  score: 0,
  lives: 3,
  wave: 1,
  waveLabel: "Hello, C++!",
  waveSub: "LESSON 1",
  weapon: 1,
  shield: false,
  rapid: 0,
  charge: 0,
  kills: 0,
  boss: null,
  bannerId: 0,
  bannerTitle: "",
  bannerTip: "",
  log: [],
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const gameRef = useRef<Game | null>(null);

  const [status, setStatus] = useState<Status>("menu");
  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [scores, setScores] = useState<ScoreEntry[]>([]);
  const [best, setBest] = useState(0);
  const [result, setResult] = useState<RunResult | null>(null);
  const [isRecord, setIsRecord] = useState(false);
  const [box, setBox] = useState({ w: 0, h: 0 });
  const [banner, setBanner] = useState<{ id: number; title: string; tip: string } | null>(null);
  const [muted, setMuted] = useState(false);

  /* ------------------------------------------------------------ sizing */
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const compute = () => {
      const availW = el.clientWidth;
      const availH = el.clientHeight;
      if (!availW || !availH) return;
      const s = Math.min(availW / W, availH / H);
      setBox({ w: Math.max(220, Math.floor(W * s)), h: Math.max(340, Math.floor(H * s)) });
    };
    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(el);
    window.addEventListener("orientationchange", compute);
    return () => {
      ro.disconnect();
      window.removeEventListener("orientationchange", compute);
    };
  }, []);

  /* ----------------------------------------------------------- engine */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas, {
      onHud: setHud,
      onStatus: setStatus,
      onGameOver: (r) => {
        setResult(r);
        setIsRecord(isHighScore(r.score));
        setScores(loadScores());
      },
    });
    gameRef.current = game;
    setMuted(sfx.loadPref());
    setScores(loadScores());
    setBest(bestScore());
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    const g = gameRef.current;
    if (g && box.w && box.h) g.resize();
  }, [box.w, box.h]);

  useEffect(() => {
    if (!scores.length) return;
    setBest((b) => Math.max(b, scores[0].score));
  }, [scores]);

  /* ---------------------------------------------------------- banner fx */
  useEffect(() => {
    if (!hud.bannerId) return;
    setBanner({ id: hud.bannerId, title: hud.bannerTitle, tip: hud.bannerTip });
    const t = window.setTimeout(() => setBanner(null), 2600);
    return () => window.clearTimeout(t);
  }, [hud.bannerId, hud.bannerTitle, hud.bannerTip]);

  /* ------------------------------------------------------------- actions */
  const start = useCallback(() => {
    sfx.unlock();
    sfx.ui();
    setResult(null);
    setIsRecord(false);
    gameRef.current?.start();
  }, []);

  const pause = useCallback(() => {
    sfx.ui();
    gameRef.current?.togglePause();
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      sfx.setMuted(!m);
      return !m;
    });
  }, []);
  const menu = useCallback(() => gameRef.current?.toMenu(), []);
  const bomb = useCallback(() => gameRef.current?.requestBomb(), []);

  const submitScore = useCallback(
    (name: string) => {
      if (!result) return;
      setScores(saveScore({ name, score: result.score, wave: result.wave, kills: result.kills, date: Date.now() }));
      setIsRecord(false);
    },
    [result],
  );

  /* ------------------------------------------------------------- hotkeys */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) return;
      const k = e.key.toLowerCase();
      if (status === "menu" && (k === "enter" || k === " ")) {
        e.preventDefault();
        start();
      } else if (status === "gameover" && (k === "r" || k === "enter" || k === " ")) {
        e.preventDefault();
        start();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [status, start]);

  useEffect(() => {
    const onVis = () => {
      const g = gameRef.current;
      if (!g) return;
      if (document.hidden && g.status === "playing") g.togglePause();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center gap-3 overflow-hidden bg-void p-2 sm:p-3 xl:flex-row xl:gap-5">
      {/* ambient page glow + faint terminal grid */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.5]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, rgba(74,159,245,0.06) 0px, rgba(74,159,245,0.06) 1px, transparent 1px, transparent 44px), repeating-linear-gradient(90deg, rgba(74,159,245,0.06) 0px, rgba(74,159,245,0.06) 1px, transparent 1px, transparent 44px)",
        }}
      />
      <div className="pointer-events-none absolute inset-0 opacity-70">
        <div className="absolute top-[-18%] left-1/2 h-[420px] w-[820px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(56,225,255,0.10),transparent_70%)] blur-2xl" />
        <div className="absolute bottom-[-22%] left-[12%] h-[360px] w-[520px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(167,139,250,0.12),transparent_70%)] blur-2xl" />
        <div className="absolute right-[8%] bottom-[-14%] h-[320px] w-[520px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(249,171,0,0.09),transparent_70%)] blur-2xl" />
      </div>

      {/* compact notebook header for narrow screens */}
      <header className="z-10 flex w-full shrink-0 items-center justify-between gap-2 px-1 xl:hidden">
        <div className="min-w-0">
          <div className="truncate text-[11px] font-extrabold tracking-[0.18em] text-ink">
            COMPILE<span className="text-cyan"> RUSH</span>
          </div>
          <div className="truncate text-[8px] tracking-[0.2em] text-faint">beginner_cpp.ipynb · g++ -std=c++17</div>
        </div>
        <div className="flex shrink-0 items-center gap-2 rounded-md border border-edge bg-black/40 px-2 py-1 text-[9px] tracking-[0.14em]">
          <span className="text-faint">BEST</span>
          <span className="font-bold tabular-nums text-amber">{best.toLocaleString()}</span>
        </div>
      </header>

      <NotebookPanel hud={hud} />

      <div ref={wrapRef} className="relative z-10 flex min-h-0 w-full flex-1 items-center justify-center self-stretch xl:w-auto xl:flex-none">
        <div
          style={{ width: box.w || undefined, height: box.h || undefined }}
          className="relative overflow-hidden rounded-xl border border-edge bg-[#050914] shadow-[0_0_0_1px_rgba(56,225,255,0.10),0_20px_80px_-20px_rgba(56,225,255,0.25)]"
        >
          <canvas
            ref={canvasRef}
            className="block h-full w-full"
            onContextMenu={(e) => e.preventDefault()}
          />

          {status !== "menu" && (
            <Hud hud={hud} status={status} best={best} onPause={pause} onBomb={bomb} muted={muted} onToggleMute={toggleMute} />
          )}

          {banner && status === "playing" && (
            <div
              key={banner.id}
              className="cr-banner pointer-events-none absolute inset-x-0 top-[18%] z-10 px-6 text-center"
            >
              <div className="inline-block max-w-full rounded-lg border border-cyan/40 bg-[#050b18]/85 px-4 py-2.5 shadow-[0_0_40px_rgba(56,225,255,0.2)]">
                <div className="text-[10px] font-extrabold tracking-[0.3em] text-cyan sm:text-xs">{banner.title}</div>
                <div className="mt-1 text-[9px] leading-snug text-dim sm:text-[10px]">{banner.tip}</div>
              </div>
            </div>
          )}

          {status === "menu" && <StartScreen best={best} onStart={start} />}
          {status === "paused" && <PauseScreen onResume={pause} onRestart={start} onMenu={menu} />}
          {status === "gameover" && result && (
            <GameOverScreen
              result={result}
              scores={scores}
              isRecord={isRecord}
              onSubmit={submitScore}
              onRestart={start}
              onMenu={menu}
            />
          )}
        </div>
      </div>

      <ScorePanel hud={hud} scores={scores} />

      {/* compact lesson ticker for narrow screens */}
      <footer className="z-10 w-full shrink-0 px-1 xl:hidden">
        <div className="flex items-center gap-2 rounded-md border border-edge bg-black/40 px-2 py-1.5">
          <span className="shrink-0 text-[8px] tracking-[0.2em] text-amber">{hud.waveSub}</span>
          <span className="min-w-0 flex-1 truncate text-[9px] text-dim">{hud.waveLabel}</span>
          <span className="shrink-0 text-[8px] tracking-[0.14em] text-faint">
            <span className="hidden sm:inline">WASD FLY · SPACE BOMB · P PAUSE</span>
            <span className="sm:hidden">DRAG TO FLY</span>
          </span>
        </div>
      </footer>
    </div>
  );
}
