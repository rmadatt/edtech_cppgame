export interface ScoreEntry {
  name: string;
  score: number;
  wave: number;
  kills: number;
  date: number;
}

const KEY = "compilerush.scores.v1";
const MAX = 8;

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((e) => e && typeof e.score === "number")
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX);
  } catch {
    return [];
  }
}

export function saveScore(entry: ScoreEntry): ScoreEntry[] {
  const next = [...loadScores(), entry].sort((a, b) => b.score - a.score).slice(0, MAX);
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable — keep in-memory table */
  }
  return next;
}

export function bestScore(): number {
  const s = loadScores();
  return s.length ? s[0].score : 0;
}

export function isHighScore(score: number): boolean {
  if (score <= 0) return false;
  const s = loadScores();
  return s.length < MAX || score > s[s.length - 1].score;
}

export function clearScores(): ScoreEntry[] {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
  return [];
}
