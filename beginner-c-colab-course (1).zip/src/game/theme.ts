export const C = {
  void: "#070b18",
  bg0: "#0a1022",
  bg1: "#101a36",
  grid: "rgba(74,159,245,0.07)",
  edge: "#22304f",
  panel: "#0d1428",
  ink: "#e8eefb",
  dim: "#8799c4",
  faint: "#4d5f8a",

  cyan: "#38e1ff",
  blue: "#4a9ff5",
  violet: "#a78bfa",
  amber: "#f9ab00",
  orange: "#ff8a3d",
  gold: "#ffd75e",
  lime: "#7ce38b",
  pink: "#ff6ba9",
  rose: "#ff5a7a",
  red: "#ff4747",
} as const;

export const FONT = '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace';
