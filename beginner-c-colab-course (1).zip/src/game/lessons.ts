export interface Lesson {
  n: string;
  title: string;
  tip: string;
  boss?: boolean;
}

/** Waves are themed on the beginner C++ course cells. */
export const LESSONS: Lesson[] = [
  {
    n: "LESSON 1",
    title: "Hello, C++!",
    tip: "A program begins running at main(). Bugs inbound — std::cout is loaded.",
  },
  {
    n: "LESSON 2",
    title: "Variables & Types",
    tip: "int for whole numbers, double for decimals, bool for true/false.",
  },
  {
    n: "LESSON 3",
    title: "Input & Arithmetic",
    tip: "std::cin reads a value. Watch the quotient — no dividing by zero.",
  },
  {
    n: "LESSON 4",
    title: "Decisions",
    tip: "if runs code only when its condition is true. else if catches the rest.",
  },
  {
    n: "LESSON 5",
    title: "LOOPS // SEGFAULT",
    tip: "A for loop repeats when you know how many times. Break the cycle!",
    boss: true,
  },
  {
    n: "LESSON 6",
    title: "Functions",
    tip: "A function is a named block you can call. Reuse your damage.",
  },
  {
    n: "LESSON 7",
    title: "Text & Vectors",
    tip: "std::vector holds a list that can grow or shrink. So can the swarm.",
  },
  {
    n: "LESSON 8",
    title: "Classes",
    tip: "A class groups related data and functions. Dog::bark() says woof.",
  },
  {
    n: "LESSON 9",
    title: "QUIZ RUNNER",
    tip: "Three questions. Type each answer and press Enter. Good luck.",
    boss: true,
  },
  {
    n: "LESSON 10",
    title: "-O2 Optimization",
    tip: "The optimizer unrolls everything. Nothing here behaves predictably.",
  },
  {
    n: "LESSON 11",
    title: "Templates",
    tip: "template<typename T> — the error messages are the real boss.",
    boss: true,
  },
  {
    n: "LESSON 12",
    title: "Undefined Behavior",
    tip: "All bets are off. The compiler owes you nothing now.",
  },
];

export function lessonForWave(wave: number): Lesson {
  if (wave <= LESSONS.length) return LESSONS[wave - 1];
  const extra = wave - LESSONS.length;
  return {
    n: `LOOP ${extra}`,
    title: extra % 3 === 0 ? "HEISENBUG" : "UB CASCADE",
    tip: "Endless build. Every wave the warnings get louder.",
    boss: extra % 3 === 0,
  };
}

export function isBossWave(wave: number): boolean {
  return lessonForWave(wave).boss === true;
}
