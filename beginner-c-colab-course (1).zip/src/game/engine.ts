import { C, FONT } from "./theme";
import { isBossWave, lessonForWave } from "./lessons";
import { sfx } from "./audio";

export const W = 540;
export const H = 840;

export type Status = "menu" | "playing" | "paused" | "gameover";

export interface HudState {
  score: number;
  lives: number;
  wave: number;
  waveLabel: string;
  waveSub: string;
  weapon: number;
  shield: boolean;
  rapid: number;
  charge: number;
  kills: number;
  boss: number | null;
  bannerId: number;
  bannerTitle: string;
  bannerTip: string;
  log: string[];
}

export interface RunResult {
  score: number;
  wave: number;
  kills: number;
}

interface Callbacks {
  onHud: (h: HudState) => void;
  onStatus: (s: Status) => void;
  onGameOver: (r: RunResult) => void;
}

type EKind = "bug" | "null" | "leak" | "boss" | "spawn";

interface Enemy {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  kind: EKind;
  t: number;
  seed: number;
  flash: number;
  fireT: number;
  score: number;
  entered: boolean;
  phase: number;
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  dmg: number;
  life: number;
  foe: boolean;
  hue: string;
}

type PKind = "spark" | "glyph" | "ring" | "smoke";

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  kind: PKind;
  glyph?: string;
  rot: number;
  vr: number;
  drag: number;
  grav: number;
}

type UKind = "O2" | "vector" | "shield" | "life" | "score";

interface Pickup {
  x: number;
  y: number;
  vy: number;
  t: number;
  kind: UKind;
  label: string;
  color: string;
}

interface Popup {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
  size: number;
}

const GLYPHS = ["{", "}", ";", "<<", ">>", "*", "&", "::", "()", "0x", "++", "#", "!=", "|"];
const PICKUPS: Record<UKind, { label: string; color: string }> = {
  O2: { label: "-O2", color: C.amber },
  vector: { label: "vec", color: C.cyan },
  shield: { label: "try", color: C.violet },
  life: { label: "+1", color: C.lime },
  score: { label: "$", color: C.gold },
};

/** Rounded-rect path that works on every canvas implementation. */
function boxPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.arcTo(x + w, y, x + w, y + rr, rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
  ctx.lineTo(x + rr, y + h);
  ctx.arcTo(x, y + h, x, y + h - rr, rr);
  ctx.lineTo(x, y + rr);
  ctx.arcTo(x, y, x + rr, y, rr);
  ctx.closePath();
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(arr: T[]): T => arr[(Math.random() * arr.length) | 0];
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: Callbacks;
  private raf = 0;
  private last = 0;
  private acc = 0;

  status: Status = "menu";

  // view
  private dpr = 1;
  private scale = 1;
  private offX = 0;
  private offY = 0;
  private bg: HTMLCanvasElement | null = null;
  private rain: HTMLCanvasElement | null = null;
  private rainCols: number[] = [];
  private rainT = 0;

  // entities
  private enemies: Enemy[] = [];
  private bullets: Bullet[] = [];
  private parts: Particle[] = [];
  private pickups: Pickup[] = [];
  private pops: Popup[] = [];

  // player
  private p = { x: W / 2, y: H - 120, r: 13 };
  private fireCd = 0;
  private invuln = 0;
  private lives = 3;
  private weapon = 1;
  private shield = false;
  private rapid = 0;
  private charge = 0;
  private bombFlash = 0;
  private thrust = 0;

  // run state
  private score = 0;
  private kills = 0;
  private wave = 1;
  private spawned = 0;
  private quota = 12;
  private spawnT = 0;
  private waveGap = 0;
  private boss: Enemy | null = null;
  private bannerId = 0;
  private bannerTitle = "";
  private bannerTip = "";
  private log: string[] = [];

  // combo / juice
  private combo = 0;
  private comboT = 0;
  private comboPop = 0;
  private shake = 0;
  private shakeX = 0;
  private shakeY = 0;
  private hitStop = 0;
  private flash = 0;
  private flashColor = "255,255,255";
  private time = 0;
  private dying = 0;

  // input
  private keys = new Set<string>();
  private pointer = { active: false, x: W / 2, y: H - 120, touch: false };
  private bombRequest = false;

  constructor(canvas: HTMLCanvasElement, cb: Callbacks) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("2d context unavailable");
    this.ctx = ctx;
    this.cb = cb;
    this.resize();
    this.bindInput();
    this.seedRain();
    this.pushHud(true);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  /* ---------------------------------------------------------------- setup */

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("pointercancel", this.onPointerUp);
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(1, rect.width);
    const h = Math.max(1, rect.height);
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);
    this.scale = Math.min(w / W, h / H);
    this.offX = (w - W * this.scale) / 2;
    this.offY = (h - H * this.scale) / 2;
    this.buildBg();
    this.buildRain();
  }

  private buildBg() {
    const cw = Math.max(1, Math.round(W * this.scale * this.dpr));
    const ch = Math.max(1, Math.round(H * this.scale * this.dpr));
    const cv = document.createElement("canvas");
    cv.width = cw;
    cv.height = ch;
    const g = cv.getContext("2d");
    if (!g) return;
    const s = this.scale * this.dpr;
    g.scale(s, s);
    const grad = g.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, "#0a1226");
    grad.addColorStop(0.55, "#080e1e");
    grad.addColorStop(1, "#050914");
    g.fillStyle = grad;
    g.fillRect(0, 0, W, H);

    // horizon glow
    const rg = g.createRadialGradient(W / 2, H * 0.92, 20, W / 2, H * 0.92, H * 0.7);
    rg.addColorStop(0, "rgba(56,225,255,0.10)");
    rg.addColorStop(0.5, "rgba(74,159,245,0.045)");
    rg.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = rg;
    g.fillRect(0, 0, W, H);

    // grid
    g.strokeStyle = C.grid;
    g.lineWidth = 1;
    g.beginPath();
    for (let x = 0; x <= W; x += 45) {
      g.moveTo(Math.round(x) + 0.5, 0);
      g.lineTo(Math.round(x) + 0.5, H);
    }
    for (let y = 0; y <= H; y += 45) {
      g.moveTo(0, Math.round(y) + 0.5);
      g.lineTo(W, Math.round(y) + 0.5);
    }
    g.stroke();

    // horizon line
    g.strokeStyle = "rgba(56,225,255,0.22)";
    g.lineWidth = 2;
    g.beginPath();
    g.moveTo(0, H - 42.5);
    g.lineTo(W, H - 42.5);
    g.stroke();

    // baked vignette (cheap: no per-frame gradient)
    const vg = g.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.8);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.6)");
    g.fillStyle = vg;
    g.fillRect(0, 0, W, H);

    this.bg = cv;
  }

  private seedRain() {
    this.rainCols = [];
    const cols = 22;
    for (let i = 0; i < cols; i++) this.rainCols.push(rand(-40, H));
  }

  private buildRain() {
    const cw = Math.max(1, Math.round(W * this.scale * this.dpr));
    const ch = Math.max(1, Math.round(H * this.scale * this.dpr));
    const cv = document.createElement("canvas");
    cv.width = cw;
    cv.height = ch;
    const g = cv.getContext("2d");
    if (!g) return;
    g.scale(this.scale * this.dpr, this.scale * this.dpr);
    g.fillStyle = "rgba(5,9,20,1)";
    g.fillRect(0, 0, W, H);
    this.rain = cv;
  }

  private stepRain() {
    const cv = this.rain;
    if (!cv) return;
    const g = cv.getContext("2d");
    if (!g) return;
    g.setTransform(this.scale * this.dpr, 0, 0, this.scale * this.dpr, 0, 0);
    g.fillStyle = "rgba(6,10,22,0.20)";
    g.fillRect(0, 0, W, H);
    g.font = `700 15px ${FONT}`;
    g.textAlign = "center";
    for (let i = 0; i < this.rainCols.length; i++) {
      const x = 14 + (i * (W - 28)) / (this.rainCols.length - 1);
      this.rainCols[i] += rand(18, 44);
      if (this.rainCols[i] > H + 30) this.rainCols[i] = rand(-60, -10);
      const y = this.rainCols[i];
      g.fillStyle = i % 5 === 0 ? "rgba(56,225,255,0.5)" : "rgba(74,159,245,0.34)";
      g.fillText(pick(GLYPHS), x, y);
    }
  }

  /* --------------------------------------------------------------- status */

  private setStatus(s: Status) {
    this.status = s;
    this.cb.onStatus(s);
  }

  start() {
    this.reset();
    this.setStatus("playing");
  }

  togglePause() {
    if (this.status === "playing") this.setStatus("paused");
    else if (this.status === "paused") this.setStatus("playing");
  }

  toMenu() {
    this.reset();
    this.setStatus("menu");
  }

  private reset() {
    this.enemies.length = 0;
    this.bullets.length = 0;
    this.parts.length = 0;
    this.pickups.length = 0;
    this.pops.length = 0;
    this.p = { x: W / 2, y: H - 120, r: 13 };
    this.lives = 3;
    this.weapon = 1;
    this.shield = false;
    this.rapid = 0;
    this.charge = 0;
    this.score = 0;
    this.kills = 0;
    this.combo = 0;
    this.comboT = 0;
    this.wave = 1;
    this.spawned = 0;
    this.spawnT = 0.5;
    this.waveGap = 0;
    this.boss = null;
    this.shake = 0;
    this.hitStop = 0;
    this.flash = 0;
    this.invuln = 1;
    this.dying = 0;
    this.bombFlash = 0;
    this.log = [];
    this.pointer.active = false;
    this.keys.clear();
    this.beginWave(1);
    this.pushHud(true);
  }

  private beginWave(n: number) {
    this.wave = n;
    const boss = isBossWave(n);
    // boss waves stay open until the boss actually spawns (quota 1) and dies
    this.quota = boss ? 1 : 11 + n * 3;
    this.spawned = 0;
    this.spawnT = boss ? 1.6 : 0.8;
    this.waveGap = 0;
    const l = lessonForWave(n);
    this.bannerId++;
    this.bannerTitle = `${l.n} — ${l.title}`;
    this.bannerTip =
      n === 1 ? `${l.tip}  ·  DRAG or WASD to fly — shooting is automatic` : l.tip;
    this.log = [`%%writefile wave${String(n).padStart(2, "0")}.cpp`, ...this.log].slice(0, 7);
    sfx.wave();
    this.pushHud(true);
  }

  /* ---------------------------------------------------------------- input */

  private bindInput() {
    window.addEventListener("keydown", this.onKeyDown, { passive: false });
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("pointercancel", this.onPointerUp);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const tag = (document.activeElement as HTMLElement | null)?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    const k = e.key.toLowerCase();
    if (["arrowleft", "arrowright", "arrowup", "arrowdown", " ", "spacebar"].includes(k)) e.preventDefault();
    if (k === "p" || k === "escape") {
      this.togglePause();
      return;
    }
    if (k === " " || k === "spacebar") {
      this.bombRequest = true;
      return;
    }
    this.keys.add(k);
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };

  private onBlur = () => {
    this.keys.clear();
    this.pointer.active = false;
    if (this.status === "playing") this.setStatus("paused");
  };

  private toWorld(cx: number, cy: number) {
    const r = this.canvas.getBoundingClientRect();
    return {
      x: (cx - r.left - this.offX) / this.scale,
      y: (cy - r.top - this.offY) / this.scale,
    };
  }

  private onPointerDown = (e: PointerEvent) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    const w = this.toWorld(e.clientX, e.clientY);
    this.pointer.active = true;
    this.pointer.touch = e.pointerType !== "mouse";
    this.pointer.x = w.x;
    this.pointer.y = this.pointer.touch ? w.y - 78 : w.y;
    e.preventDefault();
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.pointer.active) return;
    const w = this.toWorld(e.clientX, e.clientY);
    this.pointer.x = w.x;
    this.pointer.y = this.pointer.touch ? w.y - 78 : w.y;
  };

  private onPointerUp = () => {
    this.pointer.active = false;
  };

  /** DOM bomb button (mobile) */
  requestBomb() {
    this.bombRequest = true;
  }

  /* ----------------------------------------------------------------- loop */

  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame);
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.1) dt = 0.1;
    this.acc += dt;
    if (this.acc < 1 / 120) return;
    const step = Math.min(this.acc, 1 / 30);
    this.acc = 0;

    if (this.status !== "paused") {
      this.time += step;
      this.rainT += step;
      if (this.rainT > 0.075) {
        this.rainT = 0;
        this.stepRain();
      }
      this.update(step);
    }
    this.render();
  };

  private update(dt: number) {
    const raw = dt;
    if (this.hitStop > 0) {
      this.hitStop -= raw;
      dt *= 0.12;
    }
    if (this.dying > 0) {
      dt *= 0.45; // slow-motion death
      this.dying -= raw;
      if (this.dying <= 0) {
        this.setStatus("gameover");
        this.cb.onGameOver({ score: this.score, wave: this.wave, kills: this.kills });
      }
    }

    this.shake *= Math.pow(0.0016, dt);
    if (this.shake < 0.05) this.shake = 0;
    this.shakeX = rand(-1, 1) * this.shake;
    this.shakeY = rand(-1, 1) * this.shake;
    this.flash = Math.max(0, this.flash - dt * 3.2);
    this.bombFlash = Math.max(0, this.bombFlash - dt * 1.6);
    this.comboPop = Math.max(0, this.comboPop - dt * 4);

    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
    }

    this.updateParticles(dt);
    this.updatePopups(dt);

    if (this.status === "menu" || this.status === "gameover") {
      this.updateAmbient(dt);
      return;
    }
    if (this.status !== "playing") return;

    if (this.dying <= 0) {
      this.updatePlayer(dt);
      this.updateSpawner(dt);
    }
    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updatePickups(dt);
    this.collide();

    if (this.rapid > 0) this.rapid = Math.max(0, this.rapid - dt);
    if (this.invuln > 0) this.invuln = Math.max(0, this.invuln - dt);

    // wave progression
    if (this.dying <= 0) {
      if (this.boss && this.boss.hp <= 0) this.boss = null;
      if (!this.boss && this.spawned >= this.quota && this.enemies.length === 0) {
        this.waveGap += dt;
        if (this.waveGap > 0.9) {
          const bonus = 250 * this.wave;
          this.addScore(bonus, W / 2, H * 0.42, `BUILD OK +${bonus}`, C.lime, 22);
          this.shakeIt(9, "124,227,139", 0.35);
          if (this.wave % 3 === 0 && this.lives < 5) {
            this.lives++;
            this.popup(W / 2, H * 0.5, "RETRY TOKEN +1", C.lime, 16);
          }
          this.beginWave(this.wave + 1);
        }
      }
    }
    this.pushHud(false);
  }

  private updateAmbient(dt: number) {
    if (this.status !== "menu") return;
    // drifting ship + idle sparks for the menu backdrop
    this.p.x = W / 2 + Math.sin(this.time * 0.6) * 40;
    this.p.y = H - 150 + Math.sin(this.time * 1.1) * 12;
    this.invuln = 0;
    this.thrust -= dt;
    if (this.thrust <= 0) {
      this.thrust = 0.03;
      this.spark(this.p.x + rand(-4, 4), this.p.y + 12, C.cyan, 1, 40, 0.35, 0.5);
    }
  }

  /* --------------------------------------------------------------- player */

  private updatePlayer(dt: number) {
    const speed = 380;
    let kx = 0;
    let ky = 0;
    if (this.keys.has("arrowleft") || this.keys.has("a")) kx -= 1;
    if (this.keys.has("arrowright") || this.keys.has("d")) kx += 1;
    if (this.keys.has("arrowup") || this.keys.has("w")) ky -= 1;
    if (this.keys.has("arrowdown") || this.keys.has("s")) ky += 1;

    if (kx || ky) {
      const len = Math.hypot(kx, ky) || 1;
      this.p.x += (kx / len) * speed * dt;
      this.p.y += (ky / len) * speed * dt;
      this.pointer.active = false;
    } else if (this.pointer.active) {
      const f = Math.min(1, dt * 16);
      this.p.x += (this.pointer.x - this.p.x) * f;
      this.p.y += (this.pointer.y - this.p.y) * f;
    }

    this.p.x = clamp(this.p.x, 20, W - 20);
    this.p.y = clamp(this.p.y, H * 0.26, H - 34);

    // thruster
    this.thrust -= dt;
    if (this.thrust <= 0) {
      this.thrust = 0.022;
      this.spark(this.p.x + rand(-3, 3), this.p.y + 13, Math.random() < 0.5 ? C.cyan : C.blue, 1, 60, 0.3, 0.2);
    }

    // bomb
    if (this.bombRequest) {
      this.bombRequest = false;
      if (this.charge >= 100) this.bomb();
    }

    // auto-fire
    this.fireCd -= dt;
    if (this.fireCd <= 0) {
      const base = this.weapon >= 4 ? 0.15 : this.weapon === 3 ? 0.14 : 0.13;
      this.fireCd = this.rapid > 0 ? base * 0.5 : base;
      this.shoot();
    }
  }

  private shoot() {
    const s = 760;
    const mk = (dx: number, ang: number, dmg = 1) => {
      this.bullets.push({
        x: this.p.x + dx,
        y: this.p.y - 12,
        vx: Math.sin(ang) * s,
        vy: -Math.cos(ang) * s,
        r: 5,
        dmg,
        life: 1.6,
        foe: false,
        hue: this.rapid > 0 ? C.amber : C.cyan,
      });
    };
    if (this.weapon <= 1) mk(0, 0);
    else if (this.weapon === 2) {
      mk(-7, 0);
      mk(7, 0);
    } else if (this.weapon === 3) {
      mk(0, 0, 1);
      mk(-10, -0.1);
      mk(10, 0.1);
    } else {
      mk(0, 0, 1);
      mk(-8, -0.09);
      mk(8, 0.09);
      mk(-15, -0.2);
      mk(15, 0.2);
    }
    this.spark(this.p.x, this.p.y - 14, this.rapid > 0 ? C.gold : C.cyan, 2, 90, 0.12, 0);
    this.shake = Math.min(this.shake + 0.25, 30);
    sfx.shoot();
  }

  private bomb() {
    this.charge = 0;
    this.hitStop = 0.1;
    this.shakeIt(26, "255,255,255", 0.5);
    this.flash = 0.85;
    this.flashColor = "56,225,255";
    this.bombFlash = 1;
    this.clearFoeBullets();
    this.ring(this.p.x, this.p.y, C.cyan, 520, 0.75);
    this.ring(this.p.x, this.p.y, C.ink, 380, 0.5);
    for (let i = 0; i < 46; i++) {
      const a = (i / 46) * Math.PI * 2;
      this.parts.push({
        x: this.p.x,
        y: this.p.y,
        vx: Math.cos(a) * rand(260, 520),
        vy: Math.sin(a) * rand(260, 520),
        life: 0.7,
        max: 0.7,
        size: rand(2, 5),
        color: Math.random() < 0.5 ? C.cyan : C.ink,
        kind: "spark",
        rot: 0,
        vr: 0,
        drag: 2.2,
        grav: 0,
      });
    }
    for (const e of this.enemies) this.damage(e, 6, true);
    this.popup(this.p.x, this.p.y - 46, "g++ -O2 CLEAN BUILD", C.cyan, 18);
    this.log = ["!g++ -O2 clean-build && ./run", ...this.log].slice(0, 7);
    sfx.bomb();
  }

  /* -------------------------------------------------------------- spawning */

  private updateSpawner(dt: number) {
    if (isBossWave(this.wave)) {
      if (this.boss || this.spawned >= 1) return;
      this.spawnT -= dt;
      if (this.spawnT <= 0) {
        this.spawned = 1;
        this.spawnBoss();
      }
      return;
    }
    if (this.spawned >= this.quota) return;
    this.spawnT -= dt;
    if (this.spawnT > 0) return;
    const w = this.wave;
    this.spawnT = Math.max(0.24, 0.74 - w * 0.035) * rand(0.72, 1.2);

    const roll = Math.random();
    const formation = roll < 0.22 && w >= 2;
    if (formation) {
      const cx = rand(80, W - 80);
      const count = 3;
      for (let i = 0; i < count; i++) {
        this.spawnEnemy("bug", clamp(cx + (i - 1) * 58, 40, W - 40), -30 - i * 6);
      }
      this.spawned += count;
      return;
    }

    let kind: EKind = "bug";
    const r = Math.random();
    if (w >= 2 && r < 0.24) kind = "null";
    else if (w >= 3 && r < 0.36) kind = "leak";
    this.spawnEnemy(kind, rand(40, W - 40), -30);
    this.spawned++;
  }

  private spawnEnemy(kind: EKind, x: number, y: number) {
    const w = this.wave;
    let hp = 1;
    let r = 16;
    let score = 100;
    let vy = 0;
    if (kind === "bug") {
      hp = w >= 7 ? 2 : 1;
      vy = 84 + w * 4.5;
      r = 17;
      score = 100;
    } else if (kind === "null") {
      hp = 1;
      vy = 155 + w * 8;
      r = 14;
      score = 160;
    } else if (kind === "leak") {
      hp = 4 + Math.floor(w / 2);
      vy = 46 + w * 2;
      r = 24;
      score = 320;
    } else if (kind === "spawn") {
      hp = 1;
      vy = 80;
      r = 11;
      score = 60;
    }
    const e: Enemy = {
      x,
      y,
      vx: 0,
      vy,
      r,
      hp,
      maxHp: hp,
      kind,
      t: rand(0, 6),
      seed: rand(0, 1000),
      flash: 0,
      fireT: rand(1.2, 3.4),
      score,
      entered: false,
      phase: 0,
    };
    this.enemies.push(e);
    if (kind === "boss") this.boss = e;
  }

  private spawnBoss() {
    const w = this.wave;
    const hp = 45 + w * 12;
    const e: Enemy = {
      x: W / 2,
      y: -80,
      vx: 0,
      vy: 70,
      r: 46,
      hp,
      maxHp: hp,
      kind: "boss",
      t: 0,
      seed: rand(0, 1000),
      flash: 0,
      fireT: 1.4,
      score: 2500 + w * 150,
      entered: false,
      phase: 0,
    };
    this.enemies.push(e);
    this.boss = e;
    this.shakeIt(14, "255,90,122", 0.4);
    sfx.boss();
  }

  /* -------------------------------------------------------------- entities */

  private updateEnemies(dt: number) {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.t += dt;
      if (e.flash > 0) e.flash -= dt * 4;

      if (e.kind === "bug") {
        e.x += Math.sin(e.t * 2 + e.seed) * 42 * dt;
        e.y += e.vy * dt;
      } else if (e.kind === "null") {
        e.y += e.vy * dt;
        e.x += Math.cos(e.t * 6 + e.seed) * 180 * dt;
        if (e.y > H * 0.45) e.vy += 220 * dt;
      } else if (e.kind === "leak") {
        e.y += e.vy * dt;
        e.x += Math.sin(e.t * 0.9 + e.seed) * 26 * dt;
        if (Math.random() < dt * 6) this.spark(e.x + rand(-14, 14), e.y + rand(-10, 10), C.violet, 1, 20, 0.5, -20);
      } else if (e.kind === "spawn") {
        e.y += e.vy * dt;
        e.x += e.vx * dt;
      } else if (e.kind === "boss") {
        if (!e.entered) {
          e.y += e.vy * dt;
          if (e.y >= 150) {
            e.y = 150;
            e.entered = true;
          }
        } else {
          e.phase += dt;
          e.x = W / 2 + Math.sin(e.phase * 0.7) * (W / 2 - 90);
          e.y = 150 + Math.sin(e.phase * 1.3) * 22;
          e.fireT -= dt;
          if (e.fireT <= 0) {
            const hard = this.wave >= 10;
            e.fireT = hard ? 1.3 : 1.75;
            const n = hard ? 14 : 9;
            const off = rand(0, Math.PI * 2);
            for (let k = 0; k < n; k++) {
              const a = off + (k / n) * Math.PI * 2;
              this.foeBullet(e.x, e.y, Math.cos(a) * 175, Math.sin(a) * 175, C.rose, 7);
            }
            const dx = this.p.x - e.x;
            const dy = this.p.y - e.y;
            for (let k = -1; k <= 1; k++) {
              const a = Math.atan2(dy, dx) + k * 0.16;
              this.foeBullet(e.x, e.y, Math.cos(a) * 265, Math.sin(a) * 265, C.orange, 6);
            }
            this.spark(e.x, e.y + 20, C.rose, 5, 130, 0.3, 0);
            this.shakeIt(5, "255,90,122", 0.15);
          }
        }
      }

      if ((e.kind === "bug" || e.kind === "leak") && this.wave >= 2) {
        e.fireT -= dt;
        if (e.fireT <= 0 && e.y > 30 && e.y < H * 0.7) {
          e.fireT = rand(2.4, 5.2) - Math.min(1.6, this.wave * 0.12);
          const dx = this.p.x - e.x;
          const dy = this.p.y - e.y;
          const dd = Math.hypot(dx, dy) || 1;
          const sp = 200 + this.wave * 6;
          this.foeBullet(e.x, e.y, (dx / dd) * sp, (dy / dd) * sp, C.red, 6);
        }
      }

      if (e.y > H + 60 || e.x < -80 || e.x > W + 80) {
        if (e.kind === "boss") {
          e.y = 150;
          e.entered = true;
          continue;
        }
        this.enemies.splice(i, 1);
        if (e.kind !== "spawn") {
          this.combo = 0;
          this.comboT = 0;
          this.popup(clamp(e.x, 40, W - 40), H - 60, "ESCAPED", C.faint, 13);
        }
      }
    }
  }

  private foeBullet(x: number, y: number, vx: number, vy: number, hue: string, r: number) {
    if (this.bullets.length > 320) return;
    this.bullets.push({ x, y, vx, vy, r, dmg: 1, life: 6, foe: true, hue });
  }

  /** Removes every enemy bullet in place — safe to call mid-iteration. */
  private clearFoeBullets() {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      if (this.bullets[i].foe) this.bullets.splice(i, 1);
    }
  }

  private updateBullets(dt: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      if (b.life <= 0 || b.y < -30 || b.y > H + 30 || b.x < -30 || b.x > W + 30) {
        this.bullets.splice(i, 1);
      }
    }
  }

  private updatePickups(dt: number) {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const u = this.pickups[i];
      u.t += dt;
      u.y += u.vy * dt;
      u.vy = Math.min(u.vy + 26 * dt, 92);
      const dx = this.p.x - u.x;
      const dy = this.p.y - u.y;
      const d = Math.hypot(dx, dy);
      if (d < 130) {
        u.x += (dx / d) * 190 * dt;
        u.y += (dy / d) * 190 * dt;
      }
      if (d < 26) {
        this.apply(u.kind);
        this.pickups.splice(i, 1);
        continue;
      }
      if (u.y > H + 30) this.pickups.splice(i, 1);
    }
  }

  private apply(kind: UKind) {
    if (kind === "O2") {
      this.rapid = Math.min(12, this.rapid + 8);
      this.popup(this.p.x, this.p.y - 40, "-O2 RAPID", C.amber, 17);
    } else if (kind === "vector") {
      if (this.weapon < 4) {
        this.weapon++;
        this.popup(this.p.x, this.p.y - 40, `WEAPON ${this.weapon}`, C.cyan, 17);
      } else {
        this.addScore(500, this.p.x, this.p.y - 40, "+500", C.gold, 17);
      }
    } else if (kind === "shield") {
      this.shield = true;
      this.popup(this.p.x, this.p.y - 40, "try { catch }", C.violet, 17);
    } else if (kind === "life") {
      if (this.lives < 5) {
        this.lives++;
        this.popup(this.p.x, this.p.y - 40, "RETRY TOKEN +1", C.lime, 17);
      } else {
        this.addScore(800, this.p.x, this.p.y - 40, "+800", C.lime, 17);
      }
    } else {
      this.addScore(400, this.p.x, this.p.y - 40, "+400", C.gold, 17);
    }
    this.ring(this.p.x, this.p.y, PICKUPS[kind].color, 90, 0.4);
    this.shakeIt(4, "120,220,255", 0.12);
    sfx.pickup();
  }

  /* ----------------------------------------------------------- collisions */

  private collide() {
    // player bullets vs enemies
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      if (!b) break; // list shrank while resolving impacts
      if (b.foe) continue;
      for (const e of this.enemies) {
        const dx = b.x - e.x;
        const dy = b.y - e.y;
        if (dx * dx + dy * dy < (e.r + b.r) * (e.r + b.r)) {
          this.damage(e, b.dmg, false);
          this.spark(b.x, b.y, b.hue, 3, 130, 0.2, 0);
          sfx.hit();
          this.bullets.splice(i, 1);
          break;
        }
      }
    }

    if (this.dying > 0) return;

    // enemy bullets vs player
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      if (!b) break; // list shrank while resolving impacts
      if (!b.foe) continue;
      const dx = b.x - this.p.x;
      const dy = b.y - this.p.y;
      if (dx * dx + dy * dy < (this.p.r + b.r) * (this.p.r + b.r)) {
        this.bullets.splice(i, 1);
        this.hurt();
      }
    }

    // enemies vs player
    for (const e of this.enemies) {
      const dx = e.x - this.p.x;
      const dy = e.y - this.p.y;
      const rr = e.r * 0.82 + this.p.r;
      if (dx * dx + dy * dy < rr * rr) {
        if (e.kind !== "boss") this.damage(e, 3, true);
        this.hurt();
        break;
      }
    }

  }

  private damage(e: Enemy, dmg: number, silentScore: boolean) {
    if (e.hp <= 0) return;
    e.hp -= dmg;
    e.flash = 1;
    if (e.hp > 0) {
      this.spark(e.x + rand(-8, 8), e.y + rand(-8, 8), C.ink, 3, 120, 0.22, 0);
      this.shake = Math.min(this.shake + 1.2, 30);
      return;
    }
    this.kill(e, silentScore);
  }

  private kill(e: Enemy, silentScore: boolean) {
    const idx = this.enemies.indexOf(e);
    if (idx >= 0) this.enemies.splice(idx, 1);
    if (this.boss === e) this.boss = null;

    this.combo++;
    this.comboT = 2.7;
    this.comboPop = 1;
    const mult = this.multiplier();
    const gained = e.score * mult;
    this.score += gained;
    this.kills++;
    this.charge = Math.min(100, this.charge + (e.kind === "boss" ? 100 : 5));

    const col = e.kind === "boss" ? C.rose : e.kind === "leak" ? C.violet : e.kind === "null" ? C.blue : C.lime;
    const count = e.kind === "boss" ? 70 : e.kind === "leak" ? 30 : 18;
    for (let i = 0; i < count; i++) {
      const a = rand(0, Math.PI * 2);
      const sp = rand(60, e.kind === "boss" ? 460 : 240);
      this.parts.push({
        x: e.x,
        y: e.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rand(0.3, 0.85),
        max: 0.85,
        size: rand(2, e.kind === "boss" ? 8 : 5),
        color: Math.random() < 0.35 ? C.ink : col,
        kind: "spark",
        rot: 0,
        vr: 0,
        drag: 1.8,
        grav: 240,
      });
    }
    const g = 3 + (e.kind === "boss" ? 12 : 0);
    for (let i = 0; i < g; i++) {
      this.parts.push({
        x: e.x + rand(-10, 10),
        y: e.y + rand(-10, 10),
        vx: rand(-90, 90),
        vy: rand(-150, -40),
        life: rand(0.6, 1.3),
        max: 1.3,
        size: rand(11, 20),
        color: col,
        kind: "glyph",
        glyph: pick(GLYPHS),
        rot: rand(-0.5, 0.5),
        vr: rand(-3, 3),
        drag: 0.6,
        grav: 190,
      });
    }
    this.ring(e.x, e.y, col, e.kind === "boss" ? 320 : e.r * 4.5, e.kind === "boss" ? 0.7 : 0.42);
    if (!silentScore) this.popup(e.x, e.y - 6, `+${gained}${mult > 1 ? ` x${mult}` : ""}`, col, e.kind === "boss" ? 24 : 15);

    this.shakeIt(e.kind === "boss" ? 30 : e.kind === "leak" ? 8 : 4.5, "255,255,255", e.kind === "boss" ? 0.6 : 0.18);
    sfx.explode(e.kind === "boss" || e.kind === "leak");
    if (e.kind === "boss") {
      this.hitStop = 0.14;
      this.flash = 0.7;
      this.flashColor = "255,120,150";
      for (let i = 0; i < 3; i++) this.dropPickup(e.x + rand(-40, 40), e.y, true);
      this.clearFoeBullets();
      this.log = [`// segfault fixed (${this.kills} bugs)`].concat(this.log).slice(0, 7);
    } else if (Math.random() < (e.kind === "leak" ? 0.3 : 0.11)) {
      this.dropPickup(e.x, e.y, false);
    }

    if (e.kind === "leak") {
      for (let i = 0; i < 2; i++) {
        this.spawnEnemy("spawn", e.x + (i === 0 ? -18 : 18), e.y);
        const sp = this.enemies[this.enemies.length - 1];
        sp.vx = i === 0 ? -70 : 70;
        sp.vy = 90;
      }
    }
  }

  private dropPickup(x: number, y: number, strong: boolean) {
    const r = Math.random();
    let kind: UKind;
    if (strong) kind = r < 0.34 ? "life" : r < 0.68 ? "vector" : "shield";
    else kind = r < 0.34 ? "O2" : r < 0.6 ? "vector" : r < 0.8 ? "shield" : r < 0.93 ? "score" : "life";
    const meta = PICKUPS[kind];
    this.pickups.push({ x, y, vy: 40, t: 0, kind, label: meta.label, color: meta.color });
  }

  private multiplier() {
    return clamp(1 + Math.floor(this.combo / 4), 1, 10);
  }

  private hurt() {
    if (this.invuln > 0 || this.dying > 0) return;
    if (this.shield) {
      this.shield = false;
      this.invuln = 1;
      this.ring(this.p.x, this.p.y, C.violet, 150, 0.5);
      this.popup(this.p.x, this.p.y - 40, "caught!", C.violet, 17);
      this.shakeIt(9, "167,139,250", 0.2);
      for (let i = 0; i < 18; i++) this.spark(this.p.x, this.p.y, C.violet, 1, 220, 0.4, 0);
      sfx.pickup();
      return;
    }
    this.lives--;
    this.combo = 0;
    this.comboT = 0;
    this.weapon = Math.max(1, this.weapon - 1);
    this.rapid = 0;
    this.invuln = 1.9;
    this.flash = 0.75;
    this.flashColor = "255,70,90";
    this.hitStop = 0.11;
    this.shakeIt(24, "255,80,100", 0.5);
    sfx.hurt();
    for (let i = 0; i < 30; i++) {
      const a = rand(0, Math.PI * 2);
      this.parts.push({
        x: this.p.x,
        y: this.p.y,
        vx: Math.cos(a) * rand(80, 320),
        vy: Math.sin(a) * rand(80, 320),
        life: rand(0.3, 0.7),
        max: 0.7,
        size: rand(2, 6),
        color: Math.random() < 0.5 ? C.rose : C.ink,
        kind: "spark",
        rot: 0,
        vr: 0,
        drag: 2,
        grav: 120,
      });
    }
    this.clearFoeBullets();
    this.popup(this.p.x, this.p.y - 46, "RUNTIME ERROR", C.rose, 18);
    this.log = ["// runtime error: retrying…"].concat(this.log).slice(0, 7);
    if (this.lives <= 0) {
      this.dying = 1.5;
      this.shakeIt(34, "255,80,100", 0.9);
      for (let i = 0; i < 60; i++) {
        const a = rand(0, Math.PI * 2);
        this.parts.push({
          x: this.p.x,
          y: this.p.y,
          vx: Math.cos(a) * rand(60, 420),
          vy: Math.sin(a) * rand(60, 420),
          life: rand(0.5, 1.4),
          max: 1.4,
          size: rand(2, 7),
          color: pick([C.cyan, C.rose, C.ink, C.amber]),
          kind: "spark",
          rot: 0,
          vr: 0,
          drag: 1.4,
          grav: 160,
        });
      }
      this.ring(this.p.x, this.p.y, C.rose, 420, 0.9);
    }
  }

  /* ------------------------------------------------------------- particles */

  private spark(x: number, y: number, color: string, n: number, speed: number, life: number, grav: number) {
    if (this.parts.length > 620) return;
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      this.parts.push({
        x,
        y,
        vx: Math.cos(a) * speed * rand(0.3, 1),
        vy: Math.sin(a) * speed * rand(0.3, 1),
        life: life * rand(0.7, 1.2),
        max: life,
        size: rand(1.5, 3.2),
        color,
        kind: "spark",
        rot: 0,
        vr: 0,
        drag: 2.4,
        grav,
      });
    }
  }

  private ring(x: number, y: number, color: string, maxR: number, life: number) {
    this.parts.push({
      x,
      y,
      vx: 0,
      vy: 0,
      life,
      max: life,
      size: maxR,
      color,
      kind: "ring",
      rot: 0,
      vr: 0,
      drag: 0,
      grav: 0,
    });
  }

  private popup(x: number, y: number, text: string, color: string, size: number) {
    this.pops.push({ x, y, text, life: 1.05, max: 1.05, color, size });
  }

  private addScore(n: number, x: number, y: number, text: string, color: string, size: number) {
    this.score += n;
    this.popup(x, y, text, color, size);
  }

  private shakeIt(amount: number, color: string, flash: number) {
    this.shake = Math.min(34, this.shake + amount);
    if (flash > 0) {
      this.flash = Math.max(this.flash, flash * 0.7);
      this.flashColor = color;
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.parts.splice(i, 1);
        continue;
      }
      const d = Math.pow(0.5, dt * p.drag);
      p.vx *= d;
      p.vy *= d;
      p.vy += p.grav * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
  }

  private updatePopups(dt: number) {
    for (let i = this.pops.length - 1; i >= 0; i--) {
      const p = this.pops[i];
      p.life -= dt;
      p.y -= 34 * dt;
      if (p.life <= 0) this.pops.splice(i, 1);
    }
  }

  /* ------------------------------------------------------------------ hud */

  private lastHud = "";

  private pushHud(force: boolean) {
    const l = lessonForWave(this.wave);
    const h: HudState = {
      score: this.score,
      lives: this.lives,
      wave: this.wave,
      waveLabel: l.title,
      waveSub: l.n,
      weapon: this.weapon,
      shield: this.shield,
      rapid: this.rapid,
      charge: Math.round(this.charge),
      kills: this.kills,
      boss: this.boss ? this.boss.hp / this.boss.maxHp : null,
      bannerId: this.bannerId,
      bannerTitle: this.bannerTitle,
      bannerTip: this.bannerTip,
      log: this.log,
    };
    const key = `${h.score}|${h.lives}|${h.wave}|${h.weapon}|${h.shield ? 1 : 0}|${h.rapid.toFixed(1)}|${
      h.charge
    }|${h.kills}|${h.boss === null ? -1 : Math.round(h.boss * 100)}|${h.bannerId}|${h.log.length}:${h.log[0] ?? ""}`;
    if (!force && key === this.lastHud) return;
    this.lastHud = key;
    this.cb.onHud(h);
  }

  /* --------------------------------------------------------------- render */

  private render() {
    const ctx = this.ctx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = C.void;
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    const s = this.scale * this.dpr;
    ctx.setTransform(s, 0, 0, s, this.offX * this.dpr + this.shakeX * s, this.offY * this.dpr + this.shakeY * s);

    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, W, H);
    ctx.clip();

    if (this.bg) ctx.drawImage(this.bg, 0, 0, W, H);
    if (this.rain) {
      ctx.globalAlpha = 0.34;
      ctx.drawImage(this.rain, 0, 0, W, H);
      ctx.globalAlpha = 1;
    }

    this.drawPickups(ctx);
    this.drawEnemies(ctx);
    this.drawBullets(ctx);
    this.drawPlayer(ctx);
    this.drawParticles(ctx);
    this.drawPopups(ctx);
    this.drawCombo(ctx);
    this.drawFrame(ctx);

    if (this.flash > 0) {
      ctx.fillStyle = `rgba(${this.flashColor},${this.flash * 0.5})`;
      ctx.fillRect(0, 0, W, H);
    }
    if (this.bombFlash > 0) {
      const g = ctx.createRadialGradient(this.p.x, this.p.y, 10, this.p.x, this.p.y, 560);
      g.addColorStop(0, `rgba(56,225,255,${0.4 * this.bombFlash})`);
      g.addColorStop(1, "rgba(56,225,255,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
    ctx.restore();
  }

  private drawFrame(ctx: CanvasRenderingContext2D) {
    if (this.invuln > 0 && this.status === "playing" && this.dying <= 0) {
      ctx.strokeStyle = `rgba(255,90,120,${0.16 + Math.sin(this.time * 22) * 0.08})`;
      ctx.lineWidth = 8;
      ctx.strokeRect(4, 4, W - 8, H - 8);
    }
  }

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    if (this.status === "gameover" || this.dying > 0) return;
    const blink = this.invuln > 0 && Math.sin(this.time * 40) > 0 ? 0.35 : 1;
    ctx.save();
    ctx.globalAlpha = blink;
    const x = this.p.x;
    const y = this.p.y;
    ctx.translate(x, y);

    // charge ring
    if (this.charge >= 100) {
      ctx.save();
      ctx.rotate(this.time * 1.6);
      ctx.strokeStyle = `rgba(56,225,255,${0.35 + Math.sin(this.time * 9) * 0.2})`;
      ctx.lineWidth = 3;
      ctx.setLineDash([9, 11]);
      ctx.beginPath();
      ctx.arc(0, 0, 30, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    } else if (this.charge > 0) {
      ctx.strokeStyle = "rgba(56,225,255,0.5)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, 26, -Math.PI / 2, -Math.PI / 2 + (this.charge / 100) * Math.PI * 2);
      ctx.stroke();
    }

    if (this.shield) {
      ctx.save();
      ctx.rotate(this.time * 0.9);
      ctx.strokeStyle = `rgba(167,139,250,${0.55 + Math.sin(this.time * 5) * 0.2})`;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let i = 0; i <= 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const r = 30 + Math.sin(this.time * 4 + i) * 2;
        const px = Math.cos(a) * r;
        const py = Math.sin(a) * r;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }

    // engine glow
    ctx.globalCompositeOperation = "lighter";
    const eg = ctx.createRadialGradient(0, 10, 1, 0, 12, 30);
    eg.addColorStop(0, "rgba(56,225,255,0.55)");
    eg.addColorStop(1, "rgba(56,225,255,0)");
    ctx.fillStyle = eg;
    ctx.beginPath();
    ctx.arc(0, 12, 30, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";

    // hull
    const tilt = this.pointer.active ? clamp((this.pointer.x - x) * 0.004, -0.28, 0.28) : 0;
    ctx.rotate(tilt);
    ctx.fillStyle = "#0e2036";
    ctx.strokeStyle = this.rapid > 0 ? C.gold : C.cyan;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(0, -20);
    ctx.lineTo(13, 6);
    ctx.lineTo(6, 12);
    ctx.lineTo(-6, 12);
    ctx.lineTo(-13, 6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = this.rapid > 0 ? C.gold : C.cyan;
    ctx.beginPath();
    ctx.moveTo(0, -13);
    ctx.lineTo(5, 3);
    ctx.lineTo(-5, 3);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "rgba(56,225,255,0.85)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-13, 6);
    ctx.lineTo(-19, 13);
    ctx.moveTo(13, 6);
    ctx.lineTo(19, 13);
    ctx.stroke();
    ctx.restore();
  }

  private drawBullets(ctx: CanvasRenderingContext2D) {
    ctx.globalCompositeOperation = "lighter";
    for (const b of this.bullets) {
      if (b.foe) {
        ctx.fillStyle = b.hue;
        ctx.save();
        ctx.translate(b.x, b.y);
        ctx.rotate(Math.atan2(b.vy, b.vx));
        ctx.beginPath();
        ctx.moveTo(9, 0);
        ctx.lineTo(0, 6);
        ctx.lineTo(-7, 0);
        ctx.lineTo(0, -6);
        ctx.closePath();
        ctx.fill();
        ctx.globalAlpha = 0.35;
        ctx.beginPath();
        ctx.arc(0, 0, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.restore();
      } else {
        ctx.strokeStyle = b.hue;
        ctx.lineWidth = 4;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(b.x - b.vx * 0.016, b.y - b.vy * 0.016);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        ctx.globalAlpha = 0.4;
        ctx.lineWidth = 9;
        ctx.beginPath();
        ctx.moveTo(b.x - b.vx * 0.026, b.y - b.vy * 0.026);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
    ctx.globalCompositeOperation = "source-over";
  }

  private drawEnemies(ctx: CanvasRenderingContext2D) {
    for (const e of this.enemies) {
      ctx.save();
      ctx.translate(e.x, e.y);
      const flash = e.flash > 0;
      if (e.kind === "bug") this.drawBug(ctx, e, flash);
      else if (e.kind === "null") this.drawNull(ctx, e, flash);
      else if (e.kind === "leak") this.drawLeak(ctx, e, flash);
      else if (e.kind === "spawn") this.drawSpawn(ctx, e, flash);
      else this.drawBoss(ctx, e, flash);
      ctx.restore();

      if (e.kind !== "boss" && e.maxHp > 1 && e.hp < e.maxHp) {
        const w = e.r * 2;
        ctx.fillStyle = "rgba(0,0,0,0.5)";
        ctx.fillRect(e.x - w / 2, e.y - e.r - 11, w, 4);
        ctx.fillStyle = C.violet;
        ctx.fillRect(e.x - w / 2, e.y - e.r - 11, (w * e.hp) / e.maxHp, 4);
      }
    }
  }

  private drawBug(ctx: CanvasRenderingContext2D, e: Enemy, flash: boolean) {
    const body = flash ? "#ffffff" : C.lime;
    const wob = Math.sin(e.t * 9 + e.seed) * 0.14;
    ctx.rotate(wob);
    ctx.strokeStyle = body;
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    for (let i = -1; i <= 1; i++) {
      const ly = i * 7;
      const k = Math.sin(e.t * 14 + i) * 4;
      ctx.beginPath();
      ctx.moveTo(-10, ly);
      ctx.lineTo(-20 - k, ly - 5);
      ctx.moveTo(10, ly);
      ctx.lineTo(20 + k, ly - 5);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(-6, -13);
    ctx.lineTo(-13, -22);
    ctx.moveTo(6, -13);
    ctx.lineTo(13, -22);
    ctx.stroke();
    ctx.fillStyle = "#0d2418";
    ctx.beginPath();
    ctx.ellipse(0, 0, 13, 16, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = body;
    ctx.stroke();
    ctx.fillStyle = body;
    ctx.font = `800 13px ${FONT}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("x", 0, 1);
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.beginPath();
    ctx.arc(-5, -9, 1.8, 0, Math.PI * 2);
    ctx.arc(5, -9, 1.8, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawNull(ctx: CanvasRenderingContext2D, e: Enemy, flash: boolean) {
    ctx.rotate(e.t * 5);
    const c = flash ? "#ffffff" : C.blue;
    ctx.strokeStyle = c;
    ctx.lineWidth = 2.4;
    ctx.fillStyle = "rgba(74,159,245,0.16)";
    ctx.beginPath();
    ctx.moveTo(0, -16);
    ctx.lineTo(16, 0);
    ctx.lineTo(0, 16);
    ctx.lineTo(-16, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.rotate(-e.t * 5);
    ctx.fillStyle = c;
    ctx.font = `800 13px ${FONT}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("0", 0, 1);
  }

  private drawLeak(ctx: CanvasRenderingContext2D, e: Enemy, flash: boolean) {
    const c = flash ? "#ffffff" : C.violet;
    ctx.strokeStyle = c;
    ctx.lineWidth = 2.4;
    ctx.fillStyle = "rgba(167,139,250,0.15)";
    ctx.beginPath();
    for (let i = 0; i <= 22; i++) {
      const a = (i / 22) * Math.PI * 2;
      const r = e.r * (0.82 + Math.sin(a * 3 + e.t * 3) * 0.12 + Math.sin(a * 5 - e.t * 2) * 0.07);
      const px = Math.cos(a) * r;
      const py = Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = c;
    ctx.font = `800 15px ${FONT}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("&", 0, 1);
    if (Math.random() < 0.25) {
      ctx.fillStyle = "rgba(167,139,250,0.35)";
      ctx.beginPath();
      ctx.arc(rand(-12, 12), rand(-12, 12), rand(1, 3), 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawSpawn(ctx: CanvasRenderingContext2D, e: Enemy, flash: boolean) {
    ctx.rotate(e.t * 8);
    ctx.fillStyle = flash ? "#ffffff" : "rgba(167,139,250,0.85)";
    ctx.beginPath();
    ctx.arc(0, 0, e.r * 0.7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = C.violet;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  private drawBoss(ctx: CanvasRenderingContext2D, e: Enemy, flash: boolean) {
    const c = flash ? "#ffffff" : C.rose;
    ctx.save();
    ctx.rotate(e.t * 0.5);
    ctx.strokeStyle = c;
    ctx.lineWidth = 3;
    ctx.fillStyle = "rgba(255,90,122,0.12)";
    ctx.beginPath();
    for (let i = 0; i <= 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const px = Math.cos(a) * e.r;
      const py = Math.sin(a) * e.r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.rotate(-e.t * 0.8);
    ctx.strokeStyle = "rgba(255,138,61,0.85)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, e.r * 0.68, 0.4, 2.2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, e.r * 0.68, 3.5, 5.3);
    ctx.stroke();
    ctx.restore();

    ctx.fillStyle = c;
    ctx.font = `800 22px ${FONT}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("!", 0, 0);
    ctx.font = `700 9px ${FONT}`;
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.fillText("SEGFAULT", 0, 30);

    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(0, 0, 4, 0, 0, e.r * 1.6);
    g.addColorStop(0, "rgba(255,90,122,0.3)");
    g.addColorStop(1, "rgba(255,90,122,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, e.r * 1.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";
  }

  private drawPickups(ctx: CanvasRenderingContext2D) {
    for (const u of this.pickups) {
      const bob = Math.sin(u.t * 6) * 3;
      ctx.save();
      ctx.translate(u.x, u.y + bob);
      ctx.globalCompositeOperation = "lighter";
      const g = ctx.createRadialGradient(0, 0, 2, 0, 0, 26);
      g.addColorStop(0, u.color + "88");
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, 26, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = "source-over";
      ctx.rotate(Math.sin(u.t * 3) * 0.12);
      ctx.fillStyle = "#0b1224";
      ctx.strokeStyle = u.color;
      ctx.lineWidth = 2;
      const w = u.label.length > 2 ? 46 : 34;
      ctx.beginPath();
      boxPath(ctx, -w / 2, -13, w, 26, 7);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = u.color;
      ctx.font = `800 13px ${FONT}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(u.label, 0, 1);
      ctx.restore();
    }
  }

  private drawParticles(ctx: CanvasRenderingContext2D) {
    // pass 1: rings + glyphs (normal blending)
    for (const p of this.parts) {
      const a = clamp(p.life / p.max, 0, 1);
      if (p.kind === "ring") {
        const t = 1 - a;
        ctx.strokeStyle = p.color;
        ctx.globalAlpha = a * 0.8;
        ctx.lineWidth = 3 + a * 3;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (0.15 + t * 0.95), 0, Math.PI * 2);
        ctx.stroke();
      } else if (p.kind === "glyph") {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        ctx.font = `700 ${p.size}px ${FONT}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(p.glyph ?? "*", 0, 0);
        ctx.restore();
      }
    }
    ctx.globalAlpha = 1;

    // pass 2: sparks, batched into additive mode
    ctx.globalCompositeOperation = "lighter";
    for (const p of this.parts) {
      if (p.kind !== "spark") continue;
      const a = clamp(p.life / p.max, 0, 1);
      ctx.globalAlpha = a;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (0.5 + a * 0.7), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  private drawPopups(ctx: CanvasRenderingContext2D) {
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const p of this.pops) {
      const a = clamp(p.life / p.max, 0, 1);
      ctx.globalAlpha = a;
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      ctx.font = `800 ${p.size}px ${FONT}`;
      const w = ctx.measureText(p.text).width;
      ctx.fillRect(p.x - w / 2 - 6, p.y - p.size * 0.8, w + 12, p.size * 1.6);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text, p.x, p.y);
      ctx.globalAlpha = 1;
    }
  }

  private drawCombo(ctx: CanvasRenderingContext2D) {
    if (this.status !== "playing") return;
    const mult = this.multiplier();
    if (this.combo < 2) return;
    const t = clamp(this.comboT / 2.7, 0, 1);
    const cx = W / 2;
    const cy = H - 26;
    ctx.save();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const pop = 1 + this.comboPop * 0.22;
    ctx.translate(cx, cy);
    ctx.scale(pop, pop);
    ctx.fillStyle = mult >= 5 ? C.gold : C.cyan;
    ctx.font = `800 17px ${FONT}`;
    ctx.fillText(`COMBO x${mult}`, 0, 0);
    ctx.fillStyle = "rgba(255,255,255,0.18)";
    ctx.fillRect(-70, 12, 140, 4);
    ctx.fillStyle = mult >= 5 ? C.gold : C.cyan;
    ctx.fillRect(-70, 12, 140 * t, 4);
    ctx.restore();
  }
}
