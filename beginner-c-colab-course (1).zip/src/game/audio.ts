type Ctx = AudioContext;

/** Tiny procedural sound engine — no assets, no dependencies. */
class Sfx {
  private ctx: Ctx | null = null;
  private master: GainNode | null = null;
  private voices = 0;
  private unlocked = false;
  muted = false;

  private ensure(): boolean {
    if (this.muted || !this.unlocked) return false; // wait for a user gesture
    if (!this.ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return false;
      try {
        this.ctx = new AC();
      } catch {
        return false;
      }
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return true;
  }

  unlock() {
    this.unlocked = true;
    this.ensure();
  }

  /** Restores the persisted mute preference; returns the current state. */
  loadPref(): boolean {
    try {
      this.muted = localStorage.getItem("compilerush.muted") === "1";
    } catch {
      /* ignore */
    }
    if (this.master && this.ctx) this.master.gain.value = this.muted ? 0 : 0.5;
    return this.muted;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.value = m ? 0 : 0.5;
    try {
      localStorage.setItem("compilerush.muted", m ? "1" : "0");
    } catch {
      /* ignore */
    }
  }

  private get busy() {
    return this.voices > 18;
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    slideTo?: number,
    delay = 0,
  ) {
    if (!this.ensure() || !this.ctx || !this.master || this.busy) return;
    const t0 = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain).connect(this.master);
    this.voices++;
    osc.onended = () => {
      this.voices--;
      osc.disconnect();
      gain.disconnect();
    };
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  private noise(dur: number, vol: number, cutoff: number, delay = 0) {
    if (!this.ensure() || !this.ctx || !this.master || this.busy) return;
    const t0 = this.ctx.currentTime + delay;
    const len = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(cutoff, t0);
    filter.frequency.exponentialRampToValueAtTime(Math.max(80, cutoff * 0.25), t0 + dur);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(vol, t0);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(filter).connect(gain).connect(this.master);
    this.voices++;
    src.onended = () => {
      this.voices--;
      src.disconnect();
      filter.disconnect();
      gain.disconnect();
    };
    src.start(t0);
  }

  shoot() {
    this.tone(880, 0.06, "square", 0.035, 320);
  }

  private lastHit = 0;

  hit() {
    const now = performance.now();
    if (now - this.lastHit < 55) return; // rate limit machine-gun impacts
    this.lastHit = now;
    this.noise(0.05, 0.05, 2600);
  }

  explode(big = false) {
    this.noise(big ? 0.6 : 0.22, big ? 0.28 : 0.14, big ? 1800 : 2400);
    this.tone(big ? 150 : 240, big ? 0.5 : 0.18, "sawtooth", big ? 0.16 : 0.09, 40);
    if (big) this.noise(0.9, 0.18, 700, 0.05);
  }

  hurt() {
    this.tone(300, 0.35, "sawtooth", 0.16, 60);
    this.noise(0.3, 0.16, 1200);
  }

  pickup() {
    this.tone(660, 0.09, "triangle", 0.1);
    this.tone(990, 0.12, "triangle", 0.09, undefined, 0.07);
  }

  bomb() {
    this.tone(120, 0.8, "sawtooth", 0.2, 900);
    this.noise(0.9, 0.24, 3000);
  }

  wave() {
    this.tone(523, 0.1, "square", 0.07);
    this.tone(659, 0.1, "square", 0.07, undefined, 0.09);
    this.tone(784, 0.16, "square", 0.07, undefined, 0.18);
  }

  boss() {
    this.tone(70, 0.9, "sawtooth", 0.2, 42);
    this.tone(140, 0.5, "square", 0.08, 90, 0.1);
    this.noise(0.7, 0.14, 900);
  }

  ui() {
    this.tone(420, 0.06, "square", 0.06);
  }
}

export const sfx = new Sfx();
